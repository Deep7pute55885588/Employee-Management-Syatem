package employee.managment.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Addemployee extends JFrame implements ActionListener {

    JTextField tname,tfname,tadress,tphone,tadhar,temail,tsalary,tdesignation;
    JLabel tempid;
    JDateChooser tdob;
    JComboBox education;
    JButton add,back;
    Random ran = new Random();
    int num = ran.nextInt(99999);

    Addemployee(){

        JLabel heading = new JLabel("Add Employee Detail");
        heading.setBounds(320,30,500,50);
        heading.setFont(new Font("serif",Font.BOLD,25));
        add(heading);

        JLabel name =new JLabel("Name");
        name.setBounds(50,150,150,30);
        name.setFont(new Font("serif",Font.BOLD,20));
        add(name);

        tname = new JTextField();
        tname.setBounds(200,150,150,30);
       // tname.setBackground(new Color(177,252,197));
        add(tname);

        JLabel fname =new JLabel("Father Name");
        fname.setBounds(400,150,150,30);
        fname.setFont(new Font("serif",Font.BOLD,20));
        add(fname);

        tfname = new JTextField();
        tfname.setBounds(600,150,150,30);
       // tfname.setBackground(new Color(177,252,197));
        add(tfname);

        JLabel dob =new JLabel("Date of Birth");
        dob.setBounds(50,200,150,30);
        dob.setFont(new Font("serif",Font.BOLD,20));
        add(dob);

        tdob = new JDateChooser();
        tdob.setBounds(200,200,150,30);
       // tdob.setBackground(new Color(177,252,197));
        add(tdob);

        JLabel salary =new JLabel("Salary");
        salary.setBounds(400,200,150,30);
        salary.setFont(new Font("serif",Font.BOLD,20));
        add(salary);

        tsalary = new JTextField();
        tsalary.setBounds(600,200,150,30);
       // tsalary.setBackground(new Color(177,255,197));
        add(tsalary);

        JLabel adress =new JLabel("Address");
        adress.setBounds(50,250,150,30);
        adress.setFont(new Font("serif",Font.BOLD,20));
        add(adress);

        tadress = new JTextField();
        tadress.setBounds(200,250,150,30);
        //tadress.setBackground(new Color(177,255,197));
        add(tadress);

        JLabel phone =new JLabel("Phone");
        phone.setBounds(400,250,150,30);
        phone.setFont(new Font("serif",Font.BOLD,20));
        add(phone);

        tphone = new JTextField();
        tphone.setBounds(600,250,150,30);
       // tphone.setBackground(new Color(177,255,197));
        add(tphone);

        JLabel email =new JLabel("Email");
        email.setBounds(50,300,150,30);
        email.setFont(new Font("serif",Font.BOLD,20));
        add(email);

        temail = new JTextField();
        temail.setBounds(200,300,150,30);
       // temail.setBackground(new Color(177,252,197));
        add(temail);

        JLabel edu =new JLabel("Higest Education");
        edu.setBounds(400,300,150,30);
        edu.setFont(new Font("serif",Font.BOLD,20));
        add(edu);

        String item[] = {"BBA","B.TECH","BCA","BA","BSC","B.COM","MBA","MCA","MA","M.TECH","MSC","PHD"};
        education = new JComboBox(item);
       // education.setBackground(new Color(177,252,197));
        education.setBounds(600,300,150,30);
        add(education);

        JLabel empid =new JLabel("Employee Id");
        empid.setBounds(50,400,150,30);
        empid.setFont(new Font("serif",Font.BOLD,20));
        add(empid);

        tempid = new JLabel(""+num);
        tempid.setBounds(200,400,150,30);
        tempid.setFont(new Font("SAN_SARIF",Font.BOLD,20));
        tempid.setForeground(Color.BLUE);
        // temail.setBackground(new Color(177,252,197));
        add(tempid);

        JLabel aadhar = new JLabel("Aadhar");
        aadhar.setBounds(400,350,150,30);
        aadhar.setFont(new Font("SAN_SERIF",Font.BOLD,20));
        add(aadhar);

        tadhar = new JTextField();
        tadhar.setBounds(600,350,150,30);
        add(tadhar);

        JLabel designation = new JLabel("Designation");
        designation.setBounds(50,350,150,30);
        designation.setFont(new Font("SAN_SERIF",Font.BOLD,20));
        add(designation);

        tdesignation = new JTextField();
        tdesignation.setBounds(200,350,150,30);
        add(tdesignation);

        add = new JButton("ADD");
        add.setBounds(250,550,150,40);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        add(add);

        back = new JButton("BACK");
        back.setBounds(450,550,150,40);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        add(back);



        getContentPane().setBackground(new Color(163,255,188));
        setSize(900,700);
        setLocation(300,50);
        setLayout(null);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==add){
            String name = tname.getText();
            String father = tfname.getText();
            String dob = ((JTextField)tdob.getDateEditor().getUiComponent()).getText();
            String salary = tsalary.getText();
            String address = tadress.getText();
            String phone = tphone.getText();
            String designation = tdesignation.getText();
            String email = temail.getText();
            String edu = (String)education.getSelectedItem();
            String aadhar = tadhar.getText();
            String empid = tempid.getText();

            try{
                Con con = new Con();
                String q = "insert into employee values('"+name+"','"+father+"','"+dob+"','"+salary+"','"+address+"','"+phone+"','"+email+"','"+edu+"','"+designation+"','"+aadhar+"','"+empid+"')";
                con.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Employee Detail Added Successfully");
                new Main_class();
                setVisible(false);

            }catch(Exception E){
                E.printStackTrace();
            }
        } else if(e.getSource()==back) {
            new Main_class();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Addemployee();

    }
}
