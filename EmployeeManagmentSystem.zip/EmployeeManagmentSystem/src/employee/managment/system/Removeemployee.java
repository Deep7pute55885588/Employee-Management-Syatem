package employee.managment.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.util.jar.JarFile;

public class Removeemployee extends JFrame implements ActionListener {

    Choice empId;
    JButton delete,back;

    Removeemployee(){

        super("Remove Employee");

        JLabel label = new JLabel("Employee Id");
        label.setBounds(50,50,100,30);
        label.setFont(new Font("Tahoma",Font.BOLD,15));
        add(label);

        empId = new Choice();
        empId.setBounds(200,50,150,30);
        add(empId);

        try{
            Con con = new Con();
            ResultSet resultSet = con.statement.executeQuery("select * from employee");
            while(resultSet.next()){
                empId.add(resultSet.getString(11));
            }

        }catch (Exception E){
            E.printStackTrace();
        }

        JLabel labelname = new JLabel("Name");
        labelname.setBounds(50,100,100,30);
        labelname.setFont(new Font("Tahoma",Font.BOLD,15));
        add(labelname);

        JLabel tname = new JLabel();
        tname.setBounds(200,100,100,30);
        add(tname);

        JLabel labelphone = new JLabel("Phone");
        labelphone.setBounds(50,150,100,30);
        labelphone.setFont(new Font("Tahoma",Font.BOLD,15));
        add(labelphone);

        JLabel tphone = new JLabel();
        tphone.setBounds(200,150,100,30);
        add(tphone);

        JLabel labelemail = new JLabel("Email");
        labelemail.setBounds(50,200,100,30);
        labelemail.setFont(new Font("Tahoma",Font.BOLD,15));
        add(labelemail);

        JLabel temail = new JLabel();
        temail.setBounds(200,200,100,30);
        add(temail);

        try{
            Con con = new Con();
            ResultSet resultSet = con.statement.executeQuery("select * from employee where empid='"+empId.getSelectedItem()+"'");
            while(resultSet.next()){
                tname.setText(resultSet.getString(1));
                temail.setText(resultSet.getString(7));
                tphone.setText(resultSet.getString(6));
            }

        }catch(Exception EE){
            EE.printStackTrace();

        }

        empId.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                try{
                    Con con = new Con();
                    ResultSet resultSet = con.statement.executeQuery("select * from employee where empid='"+empId.getSelectedItem()+"'");
                    while(resultSet.next()) {
                        tname.setText(resultSet.getString(1));
                        temail.setText(resultSet.getString(7));
                        tphone.setText(resultSet.getString(6));
                    }
                }catch(Exception EEE){
                    EEE.printStackTrace();
                }
            }
        });

        delete = new JButton("Delete");
        delete.setBounds(80,300,100,30);
        delete.setBackground(Color.BLACK);
        delete.setForeground(Color.WHITE);
        delete.addActionListener(this);
        add(delete);

        back = new JButton("Back");
        back.setBounds(250,300,100,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/delete.png"));
        Image i2 = i1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(700,80,200,200);
        add(image);

        ImageIcon ii1 = new ImageIcon(ClassLoader.getSystemResource("Icon/rback.png"));
        Image ii2 = ii1.getImage().getScaledInstance(1120,630,Image.SCALE_DEFAULT);
        ImageIcon ii3 = new ImageIcon(ii2);
        JLabel iimage = new JLabel(ii3);
        iimage.setBounds(0,0,1120,630);
        add(iimage);

        setSize(1000,400);
        setLocation(300,150);
        setLayout(null);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==delete){
            try{
                Con con = new Con();
                String q = "delete from employee where empid='"+empId.getSelectedItem()+"'";
                con.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Employee Deleted Successfully");
                new Main_class();
                setVisible(false);

            }catch(Exception EEEE){
                EEEE.printStackTrace();
            }
        }else{
            new Main_class();
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new Removeemployee();

    }
}
