package employee.managment.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Con {

    Connection connection;
    Statement statement;

    public Con(){

        try{
           // Class forname("")
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeemanagment","Deep","Deep7pute");
            statement = connection.createStatement();

        }catch(Exception E){
            E.printStackTrace();
        }

    }

    public static void main(String[] args) {

    }
}
